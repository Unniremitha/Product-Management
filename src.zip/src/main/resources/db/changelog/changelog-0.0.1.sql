CREATE TABLE product(
    id      UUID PRIMARY KEY,
     product_code  VARCHAR(50)  UNIQUE,
     name          VARCHAR(150) ,
     category      VARCHAR(100),
     price         NUMERIC(10, 2) ,
     quantity      INTEGER,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP
);