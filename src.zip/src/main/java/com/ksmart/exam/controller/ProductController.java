package com.ksmart.exam.controller;

import com.ksmart.exam.common.Response;
import com.ksmart.exam.contract.ProductRequest;
import com.ksmart.exam.contract.ProductResponse;
import com.ksmart.exam.service.ProductService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/product")
public class ProductController {

    private final ProductService productService;

    @PostMapping("/save")
    public ResponseEntity<Response<ProductResponse>> saveProduct
            (@Valid @RequestBody ProductRequest request) {
        return new ResponseEntity<>(
                Response.<ProductResponse>builder()
                        .payload(productService.create(request))
                        .message("Product details Saved Successfully")
                        .build(),
                HttpStatus.CREATED);
    }

    @GetMapping("/listall")
    public ResponseEntity<Response<Page<ProductResponse>>> getAllProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);

        return ResponseEntity.ok(
                Response.<Page<ProductResponse>>builder()
                        .payload(productService.getAll(pageable))
                        .message("Product list fetched successfully")
                        .build()
        );
    }

    @GetMapping("/{productCode}")
    public ResponseEntity<ProductResponse> getByCode(@PathVariable String productCode) {
        return ResponseEntity.ok(productService.getByCode(productCode));
    }

    @PutMapping("/{productCode}")
    public ResponseEntity<Response<ProductResponse>> updateProduct(
           @Valid @PathVariable String productCode,
            @RequestBody ProductRequest request) {

        return ResponseEntity.ok(
                Response.<ProductResponse>builder()
                        .payload(productService.update(productCode, request))
                        .message("Product updated successfully")
                        .build()
        );
    }
    @DeleteMapping("/delete-product/{productCode}")
    public ResponseEntity<Response<String>> deleteProduct(
            @PathVariable String productCode) {
        return ResponseEntity.ok(
                Response.<String>builder()
                        .payload(productService.deleteProduct(productCode))
                        .message("DELETED")
                        .build()
        );
    }
}

