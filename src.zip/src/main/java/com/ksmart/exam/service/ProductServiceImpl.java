package com.ksmart.exam.service;

import com.ksmart.exam.contract.ProductRequest;
import com.ksmart.exam.contract.ProductResponse;
import com.ksmart.exam.exception.ProductCodeExistException;
import com.ksmart.exam.exception.ProductNotFoundException;
import com.ksmart.exam.model.Product;
import com.ksmart.exam.repository.ProductRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final ModelMapper modelMapper;

    public ProductResponse create(ProductRequest request) {
        if (productRepository.existsByProductCode(request.getProductCode())) {
            throw new ProductCodeExistException("Product code already exists");
        }
        Product product = modelMapper.map(request, Product.class);
        return modelMapper.map(productRepository.save(product), ProductResponse.class);
    }


    public Page<ProductResponse> getAll(Pageable pageable) {
        return productRepository.findAll(pageable)
                .map(product -> modelMapper.map(product, ProductResponse.class));
    }

    public ProductResponse getByCode(String productCode) {
        return productRepository.findByProductCode(productCode)
                .map(product -> modelMapper.map(product, ProductResponse.class))
                .orElseThrow(() ->
                        new ProductNotFoundException("Product not found with code: " + productCode)
                );
    }

    public ProductResponse update(String productCode, ProductRequest request) {
        Product existingProduct = productRepository.findByProductCode(productCode)
                .orElseThrow(() -> new ProductNotFoundException(productCode));


        if (request.getName() != null) {
            existingProduct.setName(request.getName());
        }

        if (request.getCategory() != null) {
            existingProduct.setCategory(request.getCategory());
        }

        if (request.getPrice() != null) {
            existingProduct.setPrice(request.getPrice());
        }

        if (request.getQuantity() != null) {
            existingProduct.setQuantity(request.getQuantity());
        }

        existingProduct.setUpdatedAt(LocalDateTime.now());

        Product saved = productRepository.save(existingProduct);

        return modelMapper.map(saved, ProductResponse.class);
    }

    @Transactional
    public String deleteProduct(String productCode) {

        Product product =
                productRepository.findByProductCode(productCode)
                        .orElseThrow(() ->
                                new ProductNotFoundException(
                                        "Product not found with code: " + productCode));

        productRepository.delete(product);

        return "Product deleted successfully";
    }
}


