package com.ksmart.exam.service;

import com.ksmart.exam.contract.ProductRequest;
import com.ksmart.exam.contract.ProductResponse;

import java.util.List;

public interface ProductService {
    ProductResponse create(ProductRequest request);
    List<ProductResponse> getAll();
    ProductResponse getByCode(String productCode);
    ProductResponse update(String productCode, ProductRequest request);
    String deleteProduct(String productCode);

}
