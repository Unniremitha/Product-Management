package com.ksmart.exam.service;

import com.ksmart.exam.contract.ProductRequest;
import com.ksmart.exam.contract.ProductResponse;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ProductService {
    ProductResponse create(ProductRequest request);
    Page<ProductResponse> getAll(Pageable pageable);
    ProductResponse getByCode(String productCode);
    ProductResponse update(String productCode, ProductRequest request);
    String deleteProduct(String productCode);

}
