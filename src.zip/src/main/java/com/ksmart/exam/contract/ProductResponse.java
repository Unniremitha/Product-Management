package com.ksmart.exam.contract;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
@Data
public class ProductResponse {
    private String productCode;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer quantity;
}
