package com.ksmart.exam.contract;

import jakarta.persistence.Column;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Data
public class ProductRequest {
    private UUID id;
    @Column(name = "product_code", unique = true, nullable = false)
    private String productCode;
    private String name;
    private String category;
    private BigDecimal price;
    private Integer quantity;
}
