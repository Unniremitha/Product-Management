package com.ksmart.exam.contract;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Data
public class ProductRequest {
    private UUID id;
    @NotBlank
    private String productCode;
    @NotBlank
    private String name;
    private String category;
    @NotNull
    private BigDecimal price;
    @NotNull
    private Integer quantity;
}
