package com.ksmart.exam.exception;

public class IdNotFound extends RuntimeException {
    public IdNotFound(String message) {
        super(message);
    }
}
