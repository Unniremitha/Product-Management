package com.ksmart.exam.exception;

public class ProductCodeExistException extends RuntimeException {
  public ProductCodeExistException(String message) {
    super(message);
  }
}
